


window.db = new Dexie("DMXPatchDB");


db.version(3).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name"
}).upgrade(tx => {
    return tx.scenes.toCollection().modify(scene => {
        if (scene.color === undefined) {
            scene.color = '#00e0ff';
        }

        if (scene.triggerType === undefined) {
            scene.triggerType = 'click';
        }

        if (scene.triggerTime === undefined) {
            scene.triggerTime = null;
        }
    });
});


db.version(4).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name",
    
    recordings: "id, fixtureId, name, duration, channelCount",
    
    kv: "&key"
});



db.version(5).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name",
    recordings: "id, fixtureId, name, duration, channelCount",
    kv: "&key",
    fixtureDetails: "fixtureId"
});


db.version(6).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name",
    recordings: "id, fixtureId, name, duration, channelCount",
    kv: "&key",
    fixtureDetails: "fixtureId",
    
    shapes: "id, fixtureId, name"
});



db.version(7).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name",
    recordings: "id, fixtureId, name, duration, channelCount",
    kv: "&key",
    fixtureDetails: "fixtureId",
    shapes: "id, fixtureId, name",
    
    movingLayouts: "id"
});


db.version(8).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name",
    recordings: "id, fixtureId, name, duration, channelCount",
    kv: "&key",
    fixtureDetails: "fixtureId",
    shapes: "id, fixtureId, name",
    movingLayouts: "id",
    
    timelines: "id, name, updatedAt"
});


db.version(9).stores({
    fixtures: "++id, address, channels, name, values",
    
    scenes: "++id, name, color, data, triggerType, triggerTime, animationId",
    customLabels: "++id, &name",
    recordings: "id, fixtureId, name, duration, channelCount",
    kv: "&key",
    fixtureDetails: "fixtureId",
    shapes: "id, fixtureId, name",
    movingLayouts: "id",
    timelines: "id, name, updatedAt"
}).upgrade(tx => {
    
    return tx.scenes.toCollection().modify(scene => {
        if (scene.animationId === undefined) scene.animationId = null;
    });
});
