(function(){
  
  window.APP_CONFIG = window.APP_CONFIG || {};
  
  const scheme = (location.protocol === 'https:') ? 'wss://' : 'ws://';
  window.APP_CONFIG.WS_URL = scheme + location.hostname + ':81/';

  
  try {
    const hasManifest = !!document.querySelector('link[rel="manifest"]');
    if (!hasManifest) {
      const link = document.createElement('link');
      link.rel = 'manifest';
      link.href = '/manifest.webmanifest';
      document.head.appendChild(link);
    }
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch(()=>{});
      });
    }
  } catch (_) {}
})();
