const idDevice = '{{idDevice}}';
let originalSceneBackup = null;

function onTriggerTypeChange(prefix) {
    const triggerTypeEl = document.getElementById(`${prefix}TriggerType`);
    const timeContainer = document.getElementById(`${prefix}TriggerTimeContainer`);
    const descElement = document.getElementById(`${prefix}TriggerDescription`);

    if (!triggerTypeEl || !timeContainer) {
        console.warn(`⚠️ Campos de trigger não encontrados para prefixo: ${prefix}`);
        return;
    }

    const triggerType = triggerTypeEl.value;
    timeContainer.style.display = triggerType === 'timed' ? 'block' : 'none';

    if (descElement) {
        let desc = '';
        switch (triggerType) {
            case 'click':
                desc = 'Executa a cena imediatamente ao clicar.'; break;
            case 'hold':
                desc = 'Executa a cena enquanto o botão estiver pressionado.'; break;
            case 'timed':
                desc = 'Executa a cena por um tempo definido em segundos.'; break;
        }
        descElement.textContent = desc;
    }
}

function openEditModal(scene) {
    editSceneId = scene.id;
    originalSceneBackup = JSON.parse(JSON.stringify(scene)); // Cópia profunda

    document.getElementById("editSceneName").value = scene.name;
    document.getElementById("editSceneColor").value = scene.color || "#00e0ff";
    document.getElementById("editTriggerType").value = scene.triggerType || 'click';
    document.getElementById("editTriggerTime").value = scene.triggerTime || '';

    renderFixturesForModal('editFixtures', scene, () => {
        onTriggerTypeChange('edit'); // ✅ Agora os elementos estão garantidamente no DOM
        document.getElementById("editModal").style.display = "flex";
    });
}

let connection;
let editSceneId = null;

window.onload = () => {
    db.open()
        .then(() => syncScenesFromAPI())
        .catch(err => console.error("Failed to open db: " + err.stack));
    connectWebSocket();
};

function connectWebSocket() {
    connection = new WebSocket('ws://' + location.hostname + ':81/');

    connection.onopen = () => {
        console.log('WebSocket Conectado com sucesso!');
        console.log('URL:', 'ws://' + location.hostname + ':81/');
        renderScenes();
    };

    connection.onclose = (event) => {
        console.log('WebSocket Desconectado. Code:', event.code, 'Reason:', event.reason);
        console.log('Tentando reconectar em 2 segundos...');
        setTimeout(connectWebSocket, 2000);
    };

    connection.onerror = (error) => {
        console.error('Erro no WebSocket:', error);
    };

    connection.onmessage = (event) => {
        console.log('Mensagem recebida do WebSocket:', event.data);
    };
}

function confirmSyncScenes() {
    if (confirm("Esta operação irá sobrescrever todas as cenas locais com os dados da API. Tem certeza que deseja continuar?")) {
        syncScenesFromAPI();
    }
}

function confirmSaveAllScenes() {
    if (confirm("Esta operação irá sobrescrever TODAS as cenas na API e pode apagar cenas não salvas.\n\nTem certeza que deseja continuar?")) {
        saveAllScenesState();
    }
}

async function applyScene(scene) {
    console.log('Applying scene:', scene);

    if (!scene || !scene.data || !Array.isArray(scene.data)) {
        console.error('Invalid scene data:', scene);
        message.error('Erro: Dados da cena inválidos');
        return;
    }

    const triggerType = scene.triggerType || 'click';
    const triggerTime = scene.triggerTime || 0;

    // Evita aplicar no clique se for tipo "hold"
    // if (triggerType === 'hold') {
    //     console.log('❌ Ignorando execução direta (modo segurar)');
    //     return;
    // }

    await applySceneBuffer(scene);

    if (triggerType === 'timed' && triggerTime > 0) {
        console.log(`⏱ Executando cena temporariamente por ${triggerTime} segundos...`);
        setTimeout(() => {
            clearDMX(); // ou reaplica cena anterior, ou envia blackout
        }, triggerTime * 1000);
    }
}

async function applySceneBuffer(scene) {
    const dmxBuffer = new Uint8Array(512);

    for (let snap of scene.data) {
        if (!snap.fixtureId && snap.fixtureId !== 0) continue;

        try {
            let fixture = await db.fixtures.get(snap.fixtureId);
            if (fixture && Array.isArray(snap.values)) {
                fixture.values = snap.values;
                await db.fixtures.put(fixture);

                for (let i = 0; i < fixture.channels && i < snap.values.length; i++) {
                    const dmxChannel = fixture.address + i;
                    if (dmxChannel >= 1 && dmxChannel <= 512) {
                        dmxBuffer[dmxChannel - 1] = snap.values[i].value;
                    }
                }
            }
        } catch (e) {
            console.error('Erro processando fixture:', e);
        }
    }

    if (connection && connection.readyState === 1) {
        try {
            connection.send(dmxBuffer);
            console.log('✅ Dados binários enviados com sucesso!');
        } catch (error) {
            console.error('❌ Erro ao enviar dados binários:', error);
        }
    } else {
        console.error('❌ WebSocket não conectado!');
    }
}

function clearDMX() {
    if (connection && connection.readyState === 1) {
        const emptyBuffer = new Uint8Array(512); // tudo zero
        connection.send(emptyBuffer);
        console.log('🧹 DMX limpo após tempo de execução.');
    }
}

async function saveAllScenesState() {
    // Busca todas as cenas locais
    const scenes = await db.scenes.toArray();

    // Monta o array para enviar
    const payload = scenes.map(s => ({
        id: s.id,
        name: s.name,
        color: s.color,
        data: s.data,
        triggerType: s.triggerType || 'click',
        triggerTime: s.triggerType !== "timed" ? null : s.triggerTime ?? null
    }));

    try {
        // Envia para a API
        const response = await fetch(`https://api.vision-cast.io/lume/device/${idDevice}/scenes`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({scenes: payload})
        });

        if (!response.ok) throw new Error('Erro ao salvar cenas na API');
        const result = await response.json();
        const apiScenes = result.data || result.scenes || result; // suporte a diferentes formatos

        // Atualiza o IndexedDB com o retorno da API
        if (Array.isArray(apiScenes)) {
            await db.scenes.clear();
            for (const s of apiScenes) {
                await db.scenes.put({
                    id: s._id,
                    name: s.name,
                    color: s.color,
                    data: s.data,
                    triggerType: s.triggerType || 'click',
                    triggerTime: s.triggerType !== "timed" ? null : s.triggerTime ?? null
                });
            }
            await renderScenes();
        }
        message.success("Cenas salvas com sucesso!");
    } catch (e) {
        message.error('Erro ao salvar cenas na API: ' + e.message);
    }
}

async function renderScenes() {
    const container = document.getElementById("sceneButtons");
    container.innerHTML = "";
    const scenes = await db.scenes.toArray();

    scenes.forEach(scene => {
        const wrapper = document.createElement("div");
        wrapper.className = "scene-card";

        const btn = document.createElement("button");
        btn.className = "scene-btn";
        btn.style.background = scene.color || "#00e0ff";
        btn.style.position = "relative"; // necessário para posicionar o lápis dentro

        btn.innerText = scene.name;
        const triggerType = scene.triggerType || 'click';

        const overlay = document.createElement("div");
        overlay.className = "hold-overlay";
        overlay.style.position = "absolute";
        overlay.style.top = "0";
        overlay.style.left = "0";
        overlay.style.right = "0";
        overlay.style.bottom = "0";
        overlay.style.background = "rgba(255, 255, 255, 0.4)"; // camada clarinha
        overlay.style.pointerEvents = "none";
        overlay.style.opacity = "0";
        overlay.style.transition = "opacity 0.2s";

        btn.appendChild(overlay);

        if (triggerType === 'click' || triggerType === 'timed') {
            btn.onclick = () => applyScene(scene);
        } else if (triggerType === 'hold') {
            let isHolding = false;

            btn.onmousedown = () => {
                if (!isHolding) {
                    isHolding = true;
                    overlay.style.opacity = "1"; // mostra o overlay
                    applyScene(scene);
                }
            };
            btn.onmouseup = btn.onmouseleave = () => {
                if (isHolding) {
                    clearDMX();
                    overlay.style.opacity = "0"; // esconde o overlay
                    isHolding = false;
                }
            };
            btn.ontouchstart = () => {
                overlay.style.opacity = "1";
                applyScene(scene);
            };
            btn.ontouchend = () => {
                clearDMX();
                overlay.style.opacity = "0";
            };

        }

        // Botão de edição (lápis) embutido no canto superior esquerdo
        const editBtn = document.createElement("button");
        editBtn.innerText = "✏️";
        editBtn.className = "edit-btn";
        editBtn.style.position = "absolute";
        editBtn.style.top = "6px";
        editBtn.style.left = "6px";
        editBtn.style.background = "rgba(0, 0, 0, 0.4)";
        editBtn.style.border = "none";
        editBtn.style.fontSize = "16px";
        editBtn.style.cursor = "pointer";
        editBtn.style.padding = "2px 5px";
        editBtn.style.borderRadius = "4px";
        editBtn.style.color = "#fff";
        editBtn.style.textShadow = "0 0 3px rgba(0,0,0,0.8)";
        editBtn.onclick = (e) => {
            e.stopPropagation();
            openEditModal(scene);
        };

        btn.appendChild(editBtn);
        wrapper.appendChild(btn);

        const delBtn = document.createElement("button");
        delBtn.innerHTML = "&times;";
        delBtn.className = "delete-btn";
        delBtn.onclick = () => deleteScene(scene.id);
        wrapper.appendChild(delBtn);

        container.appendChild(wrapper);
    });
}

async function syncScenesFromAPI() {
    try {
        const response = await fetch(`https://api.vision-cast.io/lume/device/${idDevice}/scenes`);
        if (!response.ok) throw new Error('Erro ao buscar cenas na API');
        const result = await response.json();
        const scenes = result.data;
        if (!Array.isArray(scenes)) throw new Error('Formato inesperado da resposta da API');

        await db.scenes.clear();

        for (const s of scenes) {
            await db.scenes.put({
                id: s._id,
                name: s.name,
                color: s.color,
                data: s.data,
                triggerType: s.triggerType || 'click',
                triggerTime: s.triggerType !== "timed" ? null : s.triggerTime ?? null
            });
        }
        await renderScenes();
        message.info("Cenas sincronizadas com sucesso!");
    } catch (e) {
        await renderScenes();
        message.error('Não foi possível sincronizar cenas com a API. Exibindo dados locais.\n' + e.message);
    }
}

function openCaptureModal() {
    document.getElementById("captureSceneName").value = document.getElementById("sceneName").value || "";

    // Resetar tipo e tempo de acionamento (se os campos existirem no modal de captura)
    const triggerSelect = document.getElementById("captureTriggerType");
    const triggerTime = document.getElementById("captureTriggerTime");
    if (triggerSelect) triggerSelect.value = 'click';
    if (triggerTime) triggerTime.value = '';

    if (typeof onTriggerTypeChange === 'function') onTriggerTypeChange('capture');

    renderFixturesForModal('captureFixtures', null, () => {
        document.getElementById("captureModal").style.display = "flex";
    });
}

function closeCaptureModal() {
    document.getElementById("captureModal").style.display = "none";
}

async function closeEditModal() {
    document.getElementById("editModal").style.display = "none";

    // Reverter valores DMX ao estado anterior se houver backup
    if (originalSceneBackup) {
        await applyScene(originalSceneBackup);
        originalSceneBackup = null;
    }
}

// Função auxiliar para evitar repetição de código
async function renderFixturesForModal(containerId, scene, callback) {
    const container = document.getElementById(containerId);
    container.innerHTML = "";
    const allFixtures = await db.fixtures.toArray();

    // Determina se é edição ou captura
    const isEditing = !!scene;
    const sceneData = isEditing ? scene.data : null;

    const fixturesToRender = isEditing
        ? scene.data.map(snap => {
            const fixture = allFixtures.find(f => f.id === snap.fixtureId);
            return fixture ? {...fixture, snapshot: snap} : null;
        }).filter(Boolean)
        : allFixtures.map(f => ({...f}));

    fixturesToRender.forEach((fixture, index) => {
        const values = isEditing
            ? fixture.snapshot.values
            : fixture.values;

        const div = document.createElement("div");
        div.className = "fixture";

        const title = document.createElement("div");
        title.className = "fixture-title";
        title.innerText = `${fixture.name || 'Fixture'} (${fixture.channels}ch)`;
        div.appendChild(title);

        const slidersDiv = document.createElement("div");
        slidersDiv.className = "sliders";

        for (let i = 0; i < fixture.channels; i++) {
            const sliderContainer = document.createElement("div");
            sliderContainer.className = "slider-container";

            const slider = document.createElement("input");
            slider.type = "range";
            slider.min = 0;
            slider.max = 255;
            slider.value = values[i]?.value ?? 0;
            slider.dataset.fixtureId = fixture.id;
            slider.dataset.channelIndex = i;
            slider.dataset.address = fixture.address + i;

            // Só envia update ao vivo no modo captura
            if (!isEditing) {
                slider.oninput = () => sendLiveUpdate(
                    parseInt(slider.dataset.address),
                    parseInt(slider.value)
                );
            }

            sliderContainer.appendChild(slider);

            const label = document.createElement("div");
            label.className = "slider-label";
            label.innerText = values[i]?.label || (i + 1);
            sliderContainer.appendChild(label);

            slidersDiv.appendChild(sliderContainer);
        }

        div.appendChild(slidersDiv);
        container.appendChild(div);
    });

    if (callback) callback();
}

// As funções abaixo permanecem inalteradas
async function deleteScene(id) {
    if (!confirm("Are you sure you want to delete this scene?")) return;

    try {
        // Tenta deletar na API (só se não for local)
        if (!id.startsWith('local-')) {
            const response = await fetch(`https://api.vision-cast.io/lume/device/${idDevice}/scene/${id}`, {
                method: 'DELETE'
            });
            if (!response.ok) throw new Error('Erro ao deletar cena na API');
        }
        await db.scenes.delete(id);
        message.success('Cena deletada com sucesso!');

    } catch (e) {
        message.error('Erro ao deletar cena na API. Removendo apenas localmente.');
        await db.scenes.delete(id);
    }
    await renderScenes();
}

function sendLiveUpdate(address, value) {
    if (connection && connection.readyState === 1) {
        const data = {address, value};
        console.log('Enviando update individual - Canal:', address, 'Valor:', value);
        try {
            connection.send(JSON.stringify(data));
            console.log('✅ Update individual enviado com sucesso');
        } catch (error) {
            console.error('❌ Erro ao enviar update individual:', error);
        }
    } else {
        console.error('❌ WebSocket não conectado para update individual! Estado:', connection ? connection.readyState : 'null');
    }
}

async function saveCapturedScene() {
    const name = document.getElementById("captureSceneName").value.trim();
    const color = document.getElementById("sceneColor").value;
    const triggerType = document.getElementById("editTriggerType").value;
    const triggerTime = parseInt(document.getElementById("editTriggerTime").value) || null;

    if (!name) {
        message.warning("Nome da cena é um campo obrigatório");
        return;
    }
    let snapshot = [];
    const fixtureElements = document.querySelectorAll('#captureFixtures .fixture');
    for (const fixtureDiv of fixtureElements) {
        const sliders = fixtureDiv.querySelectorAll('input[type="range"]');
        if (sliders.length > 0) {
            const fixtureId = sliders[0].dataset.fixtureId;
            // Busca a fixture no IndexedDB para pegar os labels
            const fixture = await db.fixtures.get(fixtureId);
            let newValues = Array.from(sliders).map((slider, idx) => {
                let label = fixture && fixture.values && fixture.values[idx] && fixture.values[idx].label
                    ? fixture.values[idx].label
                    : (idx + 1).toString();
                return {label, value: parseInt(slider.value)};
            });
            snapshot.push({fixtureId: fixtureId, values: newValues});
        }
    }

    try {
        // Tenta salvar na API
        const response = await fetch(`https://api.vision-cast.io/lume/scene`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                deviceId: idDevice,
                name,
                color,
                triggerType,
                triggerTime,
                data: snapshot
            })
        });

        if (!response.ok) throw new Error('Erro ao salvar cena na API');
        const json = await response.json();
        const scene = json.data;

        // Salva no IndexedDB usando o retorno da API
        await db.scenes.put({
            id: scene._id,
            name: scene.name,
            color: scene.color,
            data: scene.data,
            triggerType: scene.triggerType || 'click',
            triggerTime: scene.triggerType !== "timed" ? null : scene.triggerTime ?? null
        });
        message.success('Cena capturada com sucesso!');

    } catch (e) {
        // Se falhar, cria localmente com id customizado
        message.error('Erro ao salvar cena na API. Salvando apenas localmente.');
        await db.scenes.put({
            id: `local-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
            name,
            color,
            triggerType: triggerType || 'click',
            triggerTime: triggerType !== "timed" ? null : triggerTime ?? null,
            data: snapshot
        });
    }

    await renderScenes();
    closeCaptureModal();
    document.getElementById("sceneName").value = "";
}

async function saveEditedScene() {
    const newName = document.getElementById("editSceneName").value.trim();
    const newColor = document.getElementById("editSceneColor").value;
    if (!newName) {
        message.warning("Nome da cena é um campo obrigatório");
        return;
    }

    let scene = await db.scenes.get(editSceneId);
    scene.name = newName;
    scene.color = newColor;

    scene.data.forEach(snap => {
        const sliders = document.querySelectorAll(`#editFixtures input[data-fixture-id="${snap.fixtureId}"]`);
        snap.values = Array.from(sliders).map((sl, idx) => {
            let label = scene.fixtures?.find(f => f.id === snap.fixtureId)?.values?.[idx]?.label || (idx + 1).toString();
            return {label, value: parseInt(sl.value)};
        });
    });

    scene.triggerType = document.getElementById("editTriggerType").value;
    scene.triggerTime = parseInt(document.getElementById("editTriggerTime").value) || null;

    try {
        // Se não for local, tenta atualizar na API
        if (!scene.id.toString().startsWith("local-")) {
            const response = await fetch(`https://api.vision-cast.io/lume/device/${idDevice}/scene/${scene.id}`, {
                method: "PATCH",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({
                    name: scene.name,
                    color: scene.color,
                    data: scene.data,
                    triggerType: scene.triggerType,
                    triggerTime: scene.triggerType !== "timed" ? null : scene.triggerTime ?? null
                })
            });

            if (!response.ok) throw new Error("Erro ao salvar cena na API");

            await db.scenes.put({
                id: scene.id,
                name: scene.name,
                color: scene.color,
                triggerType: scene.triggerType,
                triggerTime: scene.triggerType !== "timed" ? null : scene.triggerTime ?? null,
                data: scene.data,
            });
        } else {
            // Salva apenas localmente se for local
            await db.scenes.put(scene);
        }
        message.success("Cena atualizada com sucesso!");

    } catch (e) {
        message.error("Erro ao salvar edição da cena na API. Salvando apenas localmente.");
        await db.scenes.put(scene);
    }

    await closeEditModal();
    await renderScenes();
}
