// db.js (modo UMD, compatível com file:// – requer que dexie.min.js esteja incluso antes deste script)
// A instância Dexie global deve estar disponível via <script src="https://unpkg.com/dexie@3/dist/dexie.min.js">

window.db = new Dexie("DMXPatchDB");

db.version(3).stores({
    fixtures: "++id, address, channels, name, values",
    scenes: "++id, name, color, data, triggerType, triggerTime",
    customLabels: "++id, &name"
}).upgrade(tx => {
    return tx.scenes.toCollection().modify(scene => {
        if (scene.color === undefined) {
            scene.color = '#00e0ff';
        }

        if (scene.triggerType === undefined) {
            scene.triggerType = 'click';
        }

        if (scene.triggerTime === undefined) {
            scene.triggerTime = null;
        }
    });
});