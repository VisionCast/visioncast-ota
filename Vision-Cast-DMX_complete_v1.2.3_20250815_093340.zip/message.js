// message.js

(function (global) {
    const containerId = 'message-container';

    function ensureContainer() {
        let container = document.getElementById(containerId);
        if (!container) {
            container = document.createElement('div');
            container.id = containerId;
            container.style.position = 'fixed';
            container.style.top = '10%';
            container.style.left = '50%';
            container.style.transform = 'translateX(-50%)';
            container.style.zIndex = '9999';
            container.style.display = 'flex';
            container.style.flexDirection = 'column';
            container.style.alignItems = 'center';
            container.style.gap = '10px';
            document.body.appendChild(container);
        }
        return container;
    }

    function showMessage(type, text, duration = 3000) {
        const container = ensureContainer();

        const msg = document.createElement('div');
        msg.className = `message ${type}`;
        msg.textContent = text;

        Object.assign(msg.style, {
            padding: '14px 24px',
            borderRadius: '8px',
            fontSize: '15px',
            fontWeight: '500',
            color: type === 'warning' ? '#000' : '#fff',
            minWidth: '240px',
            maxWidth: '80vw',
            textAlign: 'center',
            boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
            opacity: '0.95',
            backgroundColor: getBgColor(type),
            border: `1px solid ${getBorderColor(type)}`
        });

        container.appendChild(msg);

        setTimeout(() => {
            msg.style.opacity = '0';
            msg.style.transition = 'opacity 0.3s';
            setTimeout(() => msg.remove(), 300);
        }, duration);
    }

    function getBgColor(type) {
        return {
            success: '#52c41a',
            error: '#ff4d4f',
            info: '#1890ff',
            warning: '#faad14'
        }[type] || '#1890ff';
    }

    function getBorderColor(type) {
        return {
            success: '#389e0d',
            error: '#cf1322',
            info: '#096dd9',
            warning: '#d48806'
        }[type] || '#096dd9';
    }

    global.message = {
        success(text, duration) { showMessage('success', text, duration); },
        error(text, duration) { showMessage('error', text, duration); },
        info(text, duration) { showMessage('info', text, duration); },
        warning(text, duration) { showMessage('warning', text, duration); }
    };
})(window);